<?php
if (!defined('ABSPATH')) exit;

class Whatsway_Customer_Events {

    public static function init() {
        add_action('woocommerce_created_customer', [__CLASS__, 'on_customer_created'], 10, 3);
        add_action('profile_update', [__CLASS__, 'on_customer_updated'], 10, 1);
    }

    public static function on_customer_created($customer_id, $new_customer_data, $password_generated) {
        $customer = new WC_Customer($customer_id);
        Whatsway_Webhook_Sender::send('customer.created', [
            'customerId' => $customer_id,
            'email'      => $customer->get_email(),
            'phone'      => $customer->get_billing_phone(),
            'firstName'  => $customer->get_first_name(),
            'lastName'   => $customer->get_last_name(),
        ]);
    }

    public static function on_customer_updated($user_id) {
        // Only fire for WooCommerce customers, not every WP user (admins, editors, etc.)
        if (!in_array('customer', (get_userdata($user_id))->roles ?? [])) {
            return;
        }

        $customer = new WC_Customer($user_id);
        Whatsway_Webhook_Sender::send('customer.updated', [
            'customerId' => $user_id,
            'email'      => $customer->get_email(),
            'phone'      => $customer->get_billing_phone(),
            'firstName'  => $customer->get_first_name(),
            'lastName'   => $customer->get_last_name(),
        ]);
    }
}
