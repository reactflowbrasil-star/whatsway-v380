<?php
if (!defined('ABSPATH')) exit;

class Whatsway_Order_Events {

    public static function init() {
        add_action('woocommerce_checkout_order_processed', [__CLASS__, 'on_order_created'], 10, 1);

        // 🔧 FIX: Block/Store-API checkout does NOT fire
        // 'woocommerce_checkout_order_processed'. It fires this action
        // instead — without this hook, order.created never triggers for
        // any order placed through the Checkout block, which is why
        // order_created automations never ran in testing.
        add_action('woocommerce_store_api_checkout_order_processed', [__CLASS__, 'on_order_created'], 10, 1);

        add_action('woocommerce_order_status_changed', [__CLASS__, 'on_order_status_changed'], 10, 4);
    }

    /**
     * Two hooks call this now: classic checkout passes an order_id (int),
     * Store API (blocks) passes the $order object itself. Normalize both,
     * and guard against a double-send in case both hooks ever fire for the
     * same order in some WooCommerce version.
     */
    public static function on_order_created($order) {
        $order = is_object($order) ? $order : wc_get_order($order);
        if (!$order) return;

        if (get_post_meta($order->get_id(), '_whatsway_order_created_sent', true)) return;
        update_post_meta($order->get_id(), '_whatsway_order_created_sent', true);

        Whatsway_Webhook_Sender::send('order.created', self::build_order_payload($order));
    }

    public static function on_order_status_changed($order_id, $old_status, $new_status, $order) {
        if (!$order) $order = wc_get_order($order_id);
        if (!$order) return;

        $payload = self::build_order_payload($order);
        $payload['oldStatus'] = $old_status;
        $payload['newStatus'] = $new_status;

        Whatsway_Webhook_Sender::send('order.updated', $payload);
    }

    private static function build_order_payload($order) {
    $items = [];

    foreach ($order->get_items() as $item) {
        $items[] = [
            'name'     => $item->get_name(),
            'quantity' => $item->get_quantity(),
            'total'    => $item->get_total(),
        ];
    }

    $date_paid = $order->get_date_paid();

    return [
        'orderId'           => $order->get_id(),
        'orderNumber'       => $order->get_order_number(),
        'status'            => $order->get_status(),
        'currency'          => $order->get_currency(),
        'total'             => $order->get_total(),

        // Payment details
        'paymentMethod'      => $order->get_payment_method(),
        'paymentMethodTitle' => $order->get_payment_method_title(),
        'isPaid'             => $order->is_paid(),
        'datePaid'           => $date_paid
            ? $date_paid->date('c')
            : null,

        // Customer details
        'email'              => $order->get_billing_email(),
        'phone'              => $order->get_billing_phone(),
        'customerName'       => trim(
            $order->get_billing_first_name() . ' ' .
            $order->get_billing_last_name()
        ),

        'items'              => $items,

        'cartToken'          => get_post_meta(
            $order->get_id(),
            '_whatsway_cart_token',
            true
        ) ?: null,
    ];
}
}
