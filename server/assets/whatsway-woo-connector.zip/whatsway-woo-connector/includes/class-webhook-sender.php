<?php
if (!defined('ABSPATH')) exit;

class Whatsway_Webhook_Sender {

    public static function init() {
        // Nothing to hook here — just a shared utility class.
    }

    /**
     * Sends an event payload to the WhatsWay backend.
     * Silently skips if the plugin isn't configured yet.
     *
     * @param string $event e.g. "customer.created", "order.created", "cart.updated"
     * @param array  $data  event-specific payload
     */
    public static function send($event, $data) {
        $store_id = get_option('whatsway_store_id');
        $secret   = get_option('whatsway_consumer_secret');
        $channel  = get_option('whatsway_channel_id');
        $backend  = rtrim(get_option('whatsway_backend_url', 'https://app.whatsway.com'), '/');

        if (!$store_id || !$secret || !$channel) {
            return; // not configured — skip silently, don't break the store
        }

        $payload = array_merge($data, [
            'storeId'   => $store_id,
            'secret'    => $secret,
            'channelId' => $channel,
            'event'     => $event,
            'platform'  => 'woocommerce',
        ]);

        wp_remote_post($backend . '/api/ecommerce/woocommerce/webhook', [
            'method'    => 'POST',
            'timeout'   => 5,
            'blocking'  => false, // fire-and-forget, never slow down the store
            'headers'   => ['Content-Type' => 'application/json'],
            'body'      => wp_json_encode($payload),
        ]);
    }
}
