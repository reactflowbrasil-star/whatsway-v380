<?php
if (!defined('ABSPATH')) exit;

class Whatsway_Cart_Events {

    public static function init() {
        // Cart contents changed
        add_action('woocommerce_add_to_cart', [__CLASS__, 'on_cart_updated'], 10, 0);
        add_action('woocommerce_cart_item_removed', [__CLASS__, 'on_cart_updated'], 10, 0);
        add_action('woocommerce_after_cart_item_quantity_update', [__CLASS__, 'on_cart_updated'], 10, 0);

        // --- Classic (shortcode) checkout ---
        // Checkout page reached (fires once per session)
        add_action('woocommerce_before_checkout_form', [__CLASS__, 'on_checkout_started'], 10, 1);

        // Checkout form fields filled in (email/phone) -> abandoned cart candidate
        add_action('woocommerce_checkout_update_order_review', [__CLASS__, 'on_abandoned_cart_capture'], 10, 1);

        // --- Block-based checkout (Store API) ---
        // As the shopper TYPES on the Checkout block (before clicking "Place
        // order"), field changes are sent to /wc/store/v1/cart/update-customer,
        // which fires this hook in real time — this is the one we need for
        // abandoned-cart capture.
        add_action('woocommerce_store_api_cart_update_customer_from_request', [__CLASS__, 'on_abandoned_cart_capture_block'], 10, 2);

        // Fallback: also fires (later, at final "Place order" submission) via
        // /wc/store/v1/checkout — harmless to keep as a safety net.
        add_action('woocommerce_store_api_checkout_update_customer_from_request', [__CLASS__, 'on_abandoned_cart_capture_block'], 10, 2);

        // Capture the cart token the moment the order is created — priority 5
        // so it runs before Whatsway_Order_Events::on_order_created() (which
        // reads this same meta) on the same hook.
        add_action('woocommerce_checkout_order_processed', [__CLASS__, 'capture_cart_token_on_order'], 5, 1);

        // 🔧 FIX: same reason as order-events — Block/Store-API checkout
        // never fires 'woocommerce_checkout_order_processed', so without
        // this hook the cart token (and order.created) never fire for
        // orders placed via the Checkout block.
        add_action('woocommerce_store_api_checkout_order_processed', [__CLASS__, 'capture_cart_token_on_order'], 5, 1);

        // Order placed -> cart is no longer abandoned (classic checkout thank-you page)
        add_action('woocommerce_thankyou', [__CLASS__, 'on_cart_completed'], 10, 1);
    }

    /**
     * 🔧 FIX: stable, per-session identifier.
     *
     * The old implementation derived the token from the cart's CONTENT hash
     * (customer_id . '_' . cart_hash). That hash changes every time cart
     * contents change (qty update, coupon applied, etc.) and — critically —
     * WooCommerce empties the cart right after checkout, so any code reading
     * this on the thank-you page recomputed against an EMPTY cart and got a
     * broken, near-constant value like "1_" that never matched the real
     * abandoned-cart record.
     *
     * Fix: generate the token ONCE per session (a random UUID, not a content
     * hash) and store it in the WC session. Every call afterwards — during
     * abandoned-cart capture, at order creation, and at order completion —
     * returns that exact same value, regardless of what happens to the cart
     * in between. This is what actually lets the backend match the
     * abandoned_cart record to the completed order.
     */
    private static function get_cart_token() {
        if (!WC()->session) return null;

        $token = WC()->session->get('whatsway_cart_token');
        if (!$token) {
            $token = WC()->session->get_customer_id() . '_' . wp_generate_uuid4();
            WC()->session->set('whatsway_cart_token', $token);
        }
        return $token;
    }

    private static function get_cart_items() {
        $items = [];
        foreach (WC()->cart->get_cart() as $item) {
            $product = $item['data'];
            $items[] = [
                'name'     => $product ? $product->get_name() : 'Item',
                'quantity' => $item['quantity'],
                'price'    => $product ? $product->get_price() : 0,
            ];
        }
        return $items;
    }

    public static function on_cart_updated() {
        if (!WC()->cart || WC()->cart->is_empty()) return;

        Whatsway_Webhook_Sender::send('cart.updated', [
            'cartToken'     => self::get_cart_token(),
            'currency'      => get_woocommerce_currency(),
            'subtotalPrice' => (string) WC()->cart->get_subtotal(),
            'totalPrice'    => (string) WC()->cart->get_total('edit'),
            'productData'   => self::get_cart_items(),
        ]);
    }

    public static function on_checkout_started() {
        if (!WC()->cart || WC()->cart->is_empty()) return;

        // Fire only once per session to avoid spamming on every page reload
        if (WC()->session->get('whatsway_checkout_started_sent')) return;
        WC()->session->set('whatsway_checkout_started_sent', true);

        Whatsway_Webhook_Sender::send('checkout.started', [
            'cartToken'   => self::get_cart_token(),
            'currency'    => get_woocommerce_currency(),
            'totalPrice'  => (string) WC()->cart->get_total('edit'),
            'productData' => self::get_cart_items(),
        ]);
    }

    /**
     * Fires on every checkout field change. We only actually store an
     * "abandoned cart" candidate once email or phone is present — this is
     * saved immediately (no time delay). WhatsWay decides reminder timing
     * later via the automation flow, same as the Shopify integration.
     */
    public static function on_abandoned_cart_capture($post_data) {
        parse_str($post_data, $fields);

        $email = sanitize_email($fields['billing_email'] ?? '');
        $phone = sanitize_text_field($fields['billing_phone'] ?? '');

        if (empty($email) && empty($phone)) return;
        if (!WC()->cart || WC()->cart->is_empty()) return;

        $first_name = sanitize_text_field($fields['billing_first_name'] ?? '');
        $last_name  = sanitize_text_field($fields['billing_last_name'] ?? '');

        Whatsway_Webhook_Sender::send('abandoned_cart', [
            'cartToken'     => self::get_cart_token(),
            'email'         => $email,
            'phone'         => $phone,
            'customerName'  => trim($first_name . ' ' . $last_name),
            'currency'      => get_woocommerce_currency(),
            'subtotalPrice' => (string) WC()->cart->get_subtotal(),
            'totalPrice'    => (string) WC()->cart->get_total('edit'),
            'productData'   => self::get_cart_items(),
        ]);
    }

    /**
     * Block checkout equivalent of on_abandoned_cart_capture().
     * Fires on every field update the Checkout block sends to the Store API
     * (via the /wc/store/v1/checkout or /cart/update-customer endpoints).
     * $customer is the session's WC_Customer object — billing data is
     * already applied to it by WooCommerce core by the time this runs.
     */
    public static function on_abandoned_cart_capture_block($customer, $request) {
        if (!$customer) return;

        $email = $customer->get_billing_email();
        $phone = $customer->get_billing_phone();

        if (empty($email) && empty($phone)) return;
        if (!WC()->cart || WC()->cart->is_empty()) return;

        Whatsway_Webhook_Sender::send('abandoned_cart', [
            'cartToken'     => self::get_cart_token(),
            'email'         => $email,
            'phone'         => $phone,
            'customerName'  => trim($customer->get_billing_first_name() . ' ' . $customer->get_billing_last_name()),
            'currency'      => get_woocommerce_currency(),
            'subtotalPrice' => (string) WC()->cart->get_subtotal(),
            'totalPrice'    => (string) WC()->cart->get_total('edit'),
            'productData'   => self::get_cart_items(),
        ]);
    }

    /**
     * Runs on `woocommerce_checkout_order_processed`, while WC()->cart still
     * holds its real contents (WooCommerce empties the cart AFTER this hook,
     * once payment/processing succeeds). We snapshot the session's stable
     * cart token now and store it on the order, so on_cart_completed() —
     * which only runs later on the thank-you page — has a reliable value
     * to send.
     */
    public static function capture_cart_token_on_order($order) {
        // Classic checkout passes an order_id (int); Store API (blocks)
        // passes the $order object itself. Normalize both.
        $order_id = is_object($order) ? $order->get_id() : $order;
        if (!$order_id) return;

        $cart_token = self::get_cart_token();
        if (!$cart_token) return;

        update_post_meta($order_id, '_whatsway_cart_token', $cart_token);

        // 🔧 FIX: once the token is safely copied onto the order, clear it
        // from the session. Without this, the SAME browser session placing
        // a second, unrelated order (different email/phone — e.g. repeat
        // testing without clearing cookies) would reuse the exact same
        // cart token, causing the backend to match it back to the FIRST
        // order's abandoned-cart row and overwrite it with the second
        // order's data instead of creating a new row.
        // capture_cart_token_on_order always runs before on_cart_completed()
        // in the request lifecycle, and on_cart_completed reads the token
        // from post-meta (already saved above), not from the session — so
        // clearing it here is safe and doesn't affect completion tracking.
        if (WC()->session) {
            WC()->session->set('whatsway_cart_token', null);
        }
    }

    public static function on_cart_completed($order_id) {
        if (!$order_id) return;

        // Prefer the token captured at order-creation time (see
        // capture_cart_token_on_order above). Fallback to a live read is now
        // SAFE — get_cart_token() is session-based (not cart-content-based),
        // so it returns the same stable value even if WC()->cart has since
        // been emptied.
        $cart_token = get_post_meta($order_id, '_whatsway_cart_token', true);

        if (!$cart_token) {
            $cart_token = self::get_cart_token();
        }

        if (!$cart_token) return;

        $order = wc_get_order($order_id);

        Whatsway_Webhook_Sender::send('abandoned_cart.completed', [
            'cartToken' => $cart_token,
            // 🆕 Included as a safety-net key so the backend can still match
            // the cart even in the rare case a session was lost entirely
            // (e.g. order placed in a new browser/session than the one that
            // originally abandoned the cart).
            'phone'     => $order ? $order->get_billing_phone() : null,
            'orderId'   => $order_id,
        ]);
    }
}
