<?php
if (!defined('ABSPATH')) exit;

class Whatsway_Admin_Settings {

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'add_menu']);
        add_action('admin_init', [__CLASS__, 'register_settings']);
    }

    public static function add_menu() {
        add_options_page(
            'WhatsWay Connector',
            'WhatsWay Connector',
            'manage_options',
            'whatsway-connector',
            [__CLASS__, 'render_page']
        );
    }

    public static function register_settings() {
        register_setting('whatsway_settings_group', 'whatsway_store_id');
        register_setting('whatsway_settings_group', 'whatsway_consumer_secret');
        register_setting('whatsway_settings_group', 'whatsway_channel_id');
        register_setting('whatsway_settings_group', 'whatsway_backend_url');
    }

    public static function render_page() {
        ?>
        <div class="wrap">
            <h1>WhatsWay Connector Settings</h1>
            <p>Paste the Store ID, Consumer Secret, and Channel ID shown in your WhatsWay dashboard after connecting this store.</p>
            <form method="post" action="options.php">
                <?php settings_fields('whatsway_settings_group'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="whatsway_store_id">Store ID</label></th>
                        <td><input type="text" id="whatsway_store_id" name="whatsway_store_id"
                                   value="<?php echo esc_attr(get_option('whatsway_store_id')); ?>"
                                   class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><label for="whatsway_consumer_secret">Consumer Secret</label></th>
                        <td><input type="password" id="whatsway_consumer_secret" name="whatsway_consumer_secret"
                                   value="<?php echo esc_attr(get_option('whatsway_consumer_secret')); ?>"
                                   class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><label for="whatsway_channel_id">Channel ID</label></th>
                        <td><input type="text" id="whatsway_channel_id" name="whatsway_channel_id"
                                   value="<?php echo esc_attr(get_option('whatsway_channel_id')); ?>"
                                   class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><label for="whatsway_backend_url">WhatsWay Backend URL</label></th>
                        <td><input type="url" id="whatsway_backend_url" name="whatsway_backend_url"
                                   value="<?php echo esc_attr(get_option('whatsway_backend_url', 'https://app.whatsway.com')); ?>"
                                   class="regular-text" /></td>
                    </tr>
                </table>
                <?php submit_button('Save & Connect'); ?>
            </form>
            <?php
            if (get_option('whatsway_store_id') && get_option('whatsway_consumer_secret')) {
                echo '<p style="color:green;font-weight:600;">&#10003; Configured — events will now sync to WhatsWay.</p>';
            } else {
                echo '<p style="color:#b32d2e;font-weight:600;">Not configured yet — events will NOT sync until all fields are filled.</p>';
            }
            ?>
        </div>
        <?php
    }
}
