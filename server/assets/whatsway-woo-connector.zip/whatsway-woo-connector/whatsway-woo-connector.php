<?php
/**
 * Plugin Name: WhatsWay WooCommerce Connector
 * Description: Pushes customer, order, and cart events from WooCommerce to WhatsWay in real time.
 * Version: 1.0.3
 * Author: WhatsWay
 */

if (!defined('ABSPATH')) exit;

define('WHATSWAY_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WHATSWAY_PLUGIN_VERSION', '1.0.3');

// Bail early if WooCommerce isn't active — avoid fatal errors
add_action('plugins_loaded', function () {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p>WhatsWay Connector requires WooCommerce to be active.</p></div>';
        });
        return;
    }

    require_once WHATSWAY_PLUGIN_DIR . 'includes/class-webhook-sender.php';
    require_once WHATSWAY_PLUGIN_DIR . 'includes/class-customer-events.php';
    require_once WHATSWAY_PLUGIN_DIR . 'includes/class-order-events.php';
    require_once WHATSWAY_PLUGIN_DIR . 'includes/class-cart-events.php';
    require_once WHATSWAY_PLUGIN_DIR . 'admin/class-admin-settings.php';

    Whatsway_Webhook_Sender::init();
    Whatsway_Customer_Events::init();
    Whatsway_Order_Events::init();
    Whatsway_Cart_Events::init();
    Whatsway_Admin_Settings::init();
});
